import { pgTable, serial, text, integer } from "drizzle-orm/pg-core";

export const generalConfig = pgTable("general_config", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull()
});

export const programmes = pgTable("programmes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  items: text("items").notNull(),
  position: integer("position").notNull().default(0)
});

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  position: integer("position").notNull().default(0)
});
