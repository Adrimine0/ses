import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { teamMembers } from "../../db/schema.js";
import { asc } from "drizzle-orm";

export default async (req: Request) => {
  if (req.method === "GET") {
    const members = await db.select().from(teamMembers).orderBy(asc(teamMembers.position));
    return Response.json(members);
  }

  if (req.method === "POST") {
    const items = await req.json();
    if (Array.isArray(items)) {
      // Clear existing and replace
      await db.delete(teamMembers);
      if (items.length > 0) {
        await db.insert(teamMembers).values(
          items.map((item, index) => ({
            name: item.name,
            role: item.role,
            position: index,
          }))
        );
      }
      return Response.json({ success: true }, { status: 200 });
    }
    return Response.json({ error: "Invalid data" }, { status: 400 });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/equipe",
};
