import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { generalConfig } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export default async (req: Request) => {
  if (req.method === "GET") {
    const config = await db.select().from(generalConfig);
    const result: Record<string, string> = {};
    for (const c of config) {
      result[c.key] = c.value;
    }
    return Response.json(result);
  }

  if (req.method === "POST") {
    const data = await req.json();
    for (const [key, value] of Object.entries(data)) {
      if (typeof value === "string") {
        // Upsert logic
        const existing = await db.select().from(generalConfig).where(eq(generalConfig.key, key));
        if (existing.length > 0) {
          await db.update(generalConfig).set({ value }).where(eq(generalConfig.key, key));
        } else {
          await db.insert(generalConfig).values({ key, value });
        }
      }
    }
    return Response.json({ success: true }, { status: 200 });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/general",
};
