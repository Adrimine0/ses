import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { programmes } from "../../db/schema.js";
import { eq, desc, asc } from "drizzle-orm";

export default async (req: Request) => {
  if (req.method === "GET") {
    const allProgrammes = await db.select().from(programmes).orderBy(asc(programmes.position));
    return Response.json(allProgrammes);
  }

  if (req.method === "POST") {
    const items = await req.json();
    if (Array.isArray(items)) {
      // Clear existing and replace
      await db.delete(programmes);
      if (items.length > 0) {
        await db.insert(programmes).values(
          items.map((item, index) => ({
            title: item.title,
            items: item.items,
            position: index,
          }))
        );
      }
      return Response.json({ success: true }, { status: 200 });
    }
    return Response.json({ error: "Invalid data" }, { status: 400 });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/programme",
};
